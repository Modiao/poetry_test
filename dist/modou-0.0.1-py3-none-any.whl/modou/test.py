class helloworld: 
    print("Hello, modou is here for you")